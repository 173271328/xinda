# Xinda

> A Vue.js project

> Stack：Vue/Vue-cli/VueRouter/Vuex/Webpack/Babel/Less/Axios/ElementUI/MintUI

> Dev：Windows 10.0.15063 / Node 8.2.1 / Chrome 60.0.3112.90

## Build Setup ( Node 6.0+ )

``` bash
#Clone to the local
git clone https://github.com/173271328/xinda.git

#Enter the folder
cd xinda

# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

* For detailed explanation on how things work, checkout the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).

## Project Test

[Demo URL](http://115.182.107.206/qd/QD0120161003/09/xinda/) ( See Mobile version by F12 tool Ctrl+Shift+M )

### QR Code For Mobile
<img src='https://github.com/173271328/xinda/blob/master/static/images/qr.png' width="200" height="200" />
